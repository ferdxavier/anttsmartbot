Mandar o número da solicitacao
Descrever o padrao de Situação
Descrever o padrao de Tipo de documento
Descrever o valor permitido para situação que for uma criança de colo como passageiro
observacao: O número deve ficar a esquerda e como str. Descobrir como o campo deve sempre ser str
Não está fechando a pagina inicial
Quando erra passa para outra lista
