"""import cv2
import pytesseract

imagem = cv2.imread('image.jpeg')
texto = pytesseract.image_to_string(imagem)
print(texto)
"""